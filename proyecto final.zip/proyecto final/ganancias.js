document.addEventListener("DOMContentLoaded", function() {
    // Función para cargar los datos del JSON y generar la gráfica de barras
    function cargarDatosYGenerarGrafica() {
        fetch('https://raw.githubusercontent.com/fgs110985/PruebaRepositorioGit/main/imdb_top_1000.json')
            .then(response => response.json())
            .then(data => {
                generarGraficaBarras(data);
            })
            .catch(error => {
                console.error('Error al cargar los datos:', error);
            });
    }

    // Función para generar la gráfica de barras con la media de dinero ganado por año
    function generarGraficaBarras(datos) {
        // Objeto para almacenar las sumas de dinero ganado por año
        const sumasPorAnio = {};
        // Objeto para almacenar el número de películas por año
        const conteoPorAnio = {};

        // Calcular la suma de dinero ganado y el número de películas por año
        datos.forEach(pelicula => {
            const año = pelicula.Released_Year;
            const ganancias = parseInt(pelicula.Gross.replace(/,/g, '').replace('$', ''), 10);

            if (!isNaN(ganancias)) {
                sumasPorAnio[año] = (sumasPorAnio[año] || 0) + ganancias;
                conteoPorAnio[año] = (conteoPorAnio[año] || 0) + 1;
            }
        });

        // Calcular la media de dinero ganado por año
        const mediaPorAnio = {};
        for (const año in sumasPorAnio) {
            mediaPorAnio[año] = sumasPorAnio[año] / conteoPorAnio[año];
        }

        // Obtener años ordenados
        const añosOrdenados = Object.keys(mediaPorAnio).sort();

        // Datos para la gráfica de barras
        const datosGrafica = añosOrdenados.map(año => mediaPorAnio[año]);

        // Inicializar la gráfica de barras
        var barChart = echarts.init(document.getElementById('barChart'));

        // Configurar las opciones de la gráfica de barras
        var option = {
            title: {
                text: 'Media de dinero ganado por año'
            },
            xAxis: {
                type: 'category',
                data: añosOrdenados
            },
            yAxis: {
                type: 'value'
            },
            series: [{
                data: datosGrafica,
                type: 'bar'
            }]
        };

        // Establecer la opción en la gráfica de barras
        barChart.setOption(option);
    }

    // Cargar datos y generar la gráfica de barras cuando la página esté lista
    cargarDatosYGenerarGrafica();
});
