document.addEventListener("DOMContentLoaded", function() {
    // Función para cargar los datos del JSON y generar la gráfica de tarta
    function cargarDatosYGenerarGrafica() {
        fetch('https://raw.githubusercontent.com/fgs110985/PruebaRepositorioGit/main/imdb_top_1000.json')
            .then(response => response.json())
            .then(data => {
                generarGraficaTarta(data);
            })
            .catch(error => {
                console.error('Error al cargar los datos:', error);
            });
    }

    // Función para generar la gráfica de tarta con el número de películas por año
    function generarGraficaTarta(datos) {
        // Obtener los años y contar el número de películas por año
        const years = datos.map(item => item.Released_Year);
        const yearCount = {};
        years.forEach(year => {
            if (yearCount[year]) {
                yearCount[year]++;
            } else {
                yearCount[year] = 1;
            }
        });

        // Inicializar la gráfica de tarta
        var pieChart = echarts.init(document.getElementById('pieChart'));

        // Configurar las opciones de la gráfica de tarta
        var option = {
            title: {
                text: 'Número de películas por año',
                left: 'left', // Alinear el título al centro
                top: 20 // Colocar el título 20px desde arriba
            },
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c} ({d}%)'
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                top: 50, // Ajustar la leyenda para que comience 50px desde arriba
                data: Object.keys(yearCount)
            },
            series: [{
                name: 'Año',
                type: 'pie',
                radius: '70%', // Ajustar el radio de la gráfica para hacerla más grande
                center: ['50%', '60%'],
                data: Object.keys(yearCount).map(year => {
                    return {
                        name: year,
                        value: yearCount[year]
                    };
                }),
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }],
            grid: {
                top: '60%', // Ajustar la posición del gráfico hacia abajo
                bottom: '20%' // Ajustar la posición del gráfico hacia arriba
            }
        };

        // Establecer la opción en la gráfica de tarta
        pieChart.setOption(option);
    }

    // Cargar datos y generar la gráfica de tarta cuando la página esté lista
    cargarDatosYGenerarGrafica();
});
