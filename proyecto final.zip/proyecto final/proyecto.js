document.addEventListener("DOMContentLoaded", function() {
    // Constantes
    const cardsPorPagina = 20;

    // Función para cargar los datos del JSON y generar las cards
    function cargarDatos() {
        return fetch('https://raw.githubusercontent.com/fgs110985/PruebaRepositorioGit/main/imdb_top_1000.json')
            .then(response => response.json())
            .then(data => {
                return data;
            })
            .catch(error => {
                console.error('Error al cargar los datos:', error);
                return [];
            });
    }

    // Función para generar las cards
    function generarCards(data) {
        const cardContainer = document.getElementById('cardContainer');
        cardContainer.innerHTML = ''; // Limpiar el contenedor antes de agregar nuevas cards

        const paginacion = document.getElementById('pagination');
        paginacion.innerHTML = ''; // Limpiar la paginación antes de agregar nuevos enlaces

        // Calcular el número total de páginas
        const numPaginas = Math.ceil(data.length / cardsPorPagina);

        // Obtener el número de la página actual (a partir de la query string si está presente)
        const params = new URLSearchParams(window.location.search);
        let paginaActual = parseInt(params.get('pagina')) || 1;

        // Calcular el índice inicial y final para las cards de la página actual
        const inicio = (paginaActual - 1) * cardsPorPagina;
        const fin = Math.min(inicio + cardsPorPagina, data.length);

        // Generar las cards para la página actual
        for (let i = inicio; i < fin; i++) {
            const item = data[i];
            const card = `
                <div class="uk-width-1-3@s">
                    <div class="uk-card uk-card-default uk-card-body">
                        <img class="poster-img" src="${item.Poster_Link}" alt="Poster">
                        <h3 class="uk-card-title">${item.Series_Title}</h3>
                        <p>Año: ${item.Released_Year}, Ganancias: ${item.Gross}</p>
                    </div>
                </div>
            `;
            cardContainer.innerHTML += card;
        }

        // Generar la paginación
        for (let i = 1; i <= numPaginas; i++) {
            const enlacePagina = document.createElement('li');
            enlacePagina.innerHTML = `<a href="?pagina=${i}">${i}</a>`;
            if (i === paginaActual) {
                enlacePagina.classList.add('uk-active');
            }
            paginacion.appendChild(enlacePagina);
        }
    }
    
 // Función para agregar enlaces al menú
// Función para agregar enlaces al menú
function agregarEnlacesMenu() {
    const offcanvasNav = document.getElementById('offcanvas-nav');
    const menuContent = offcanvasNav.querySelector('.uk-offcanvas-bar');

    // Crear una lista desordenada para los enlaces
    const listaEnlaces = document.createElement('ul');
    menuContent.appendChild(listaEnlaces);

    // Crear y agregar enlaces como elementos de lista
    const enlaceGananciasPorAnio = document.createElement('li');
    const enlaceGananciasPorAnioA = document.createElement('a');
    enlaceGananciasPorAnioA.textContent = 'Ganancia media por año';
    enlaceGananciasPorAnioA.href = 'ganancias.html';
    enlaceGananciasPorAnio.appendChild(enlaceGananciasPorAnioA);
    listaEnlaces.appendChild(enlaceGananciasPorAnio);

    const enlacePeliculasPorAnio = document.createElement('li');
    const enlacePeliculasPorAnioA = document.createElement('a');
    enlacePeliculasPorAnioA.textContent = 'Número de películas por año';
    enlacePeliculasPorAnioA.href = 'peliculas.html';
    enlacePeliculasPorAnio.appendChild(enlacePeliculasPorAnioA);
    listaEnlaces.appendChild(enlacePeliculasPorAnio);
}


    // Cargar datos y generar cards y gráficas cuando la página esté lista
    cargarDatos()
        .then(data => {
            generarCards(data);
            agregarEnlacesMenu();
        })
        .catch(error => console.error('Error al cargar los datos:', error));
});

